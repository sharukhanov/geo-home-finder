import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertAttractionPointSchema } from "@shared/schema";

const formSchema = insertAttractionPointSchema.extend({
  type: z.enum(["home", "work", "study", "fitness", "hobby", "family", "shopping", "other"]),
  travelTimeMinutes: z.number().min(10).max(60),
});

type FormData = z.infer<typeof formSchema>;

interface AttractionPointFormProps {
  selectedPoint: {lat: number, lng: number} | null;
  onClearSelectedPoint: () => void;
}

const pointTypeOptions = [
  { value: "home", label: "🏠 Дом" },
  { value: "work", label: "🏢 Работа" },
  { value: "study", label: "🎓 Учеба" },
  { value: "fitness", label: "💪 Фитнес" },
  { value: "hobby", label: "🎨 Хобби" },
  { value: "family", label: "👨‍👩‍👧‍👦 Семья" },
  { value: "shopping", label: "🛍️ Покупки" },
  { value: "other", label: "📍 Другое" },
];

export function AttractionPointForm({ selectedPoint, onClearSelectedPoint }: AttractionPointFormProps) {
  const [travelTime, setTravelTime] = useState([30]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      userId: "default-user",
      type: "home",
      name: "",
      address: "",
      latitude: 55.7558,
      longitude: 37.6176,
      travelTimeMinutes: 30,
    },
  });

  const createPointMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest("POST", "/api/attraction-points", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attraction-points"] });
      form.reset();
      setTravelTime([30]);
      onClearSelectedPoint();
      toast({
        title: "Точка добавлена",
        description: "Точка притяжения успешно добавлена на карту",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось добавить точку притяжения",
        variant: "destructive",
      });
    },
  });

  // Update form when point is selected on map
  useEffect(() => {
    if (selectedPoint) {
      form.setValue("latitude", selectedPoint.lat);
      form.setValue("longitude", selectedPoint.lng);
      form.setValue("address", `${selectedPoint.lat.toFixed(4)}, ${selectedPoint.lng.toFixed(4)}`);
    }
  }, [selectedPoint]);

  // Update form when sliders change
  useEffect(() => {
    form.setValue("travelTimeMinutes", travelTime[0]);
  }, [travelTime]);



  const onSubmit = (data: FormData) => {
    if (!data.address.trim()) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, введите адрес или выберите место на карте",
        variant: "destructive",
      });
      return;
    }

    // Set name based on type if not provided
    if (!data.name.trim()) {
      const typeOption = pointTypeOptions.find(option => option.value === data.type);
      data.name = typeOption?.label || data.type;
    }

    createPointMutation.mutate(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Тип места</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите тип места" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {pointTypeOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Название (необязательно)</FormLabel>
              <FormControl>
                <Input placeholder="Например: Офис, Спортзал..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="address"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Адрес</FormLabel>
              <FormControl>
                <Input 
                  placeholder="Введите адрес или кликните на карте" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="space-y-3">
          <Label>Максимальное время в пути: {travelTime[0]} мин</Label>
          <div className="text-xs text-slate-600 mb-2 p-2 bg-slate-50 rounded">
            На общественном транспорте + пешком до точки
          </div>
          <Slider
            value={travelTime}
            onValueChange={setTravelTime}
            max={60}
            min={10}
            step={10}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-slate-500">
            <span>10 мин</span>
            <span>60 мин</span>
          </div>
          <div className="text-xs text-slate-600">
            <strong>Зоны:</strong> Идеально {Math.round(travelTime[0] * 0.7)} мин • Хорошо {travelTime[0]} мин • Далеко {Math.round(travelTime[0] * 1.3)} мин
          </div>
        </div>



        <Button 
          type="submit" 
          className="w-full"
          disabled={createPointMutation.isPending}
        >
          {createPointMutation.isPending ? "Добавляем..." : "Добавить точку"}
        </Button>
      </form>
    </Form>
  );
}
