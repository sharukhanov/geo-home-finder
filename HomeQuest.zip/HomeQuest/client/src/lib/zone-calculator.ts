import type { AttractionPoint } from "@shared/schema";
import { calculateDistance, calculateZoneRadius } from "./map-utils";

export interface CalculatedZone {
  centerLat: number;
  centerLng: number;
  radius: number;
  type: "ideal" | "good" | "far";
  pointId: number;
  score: number;
}

export interface ZoneAnalysis {
  zones: CalculatedZone[];
  optimalAreas: Array<{
    lat: number;
    lng: number;
    score: number;
    reasons: string[];
  }>;
}

// Calculate zones for all attraction points
export function calculateOptimalZones(attractionPoints: AttractionPoint[]): ZoneAnalysis {
  const zones: CalculatedZone[] = [];

  // Generate zones for each attraction point
  attractionPoints.forEach(point => {
    const zoneRadii = calculateZoneRadius(point.travelTimeMinutes, point.priority);
    
    // Create ideal zone
    zones.push({
      centerLat: point.latitude,
      centerLng: point.longitude,
      radius: zoneRadii.ideal,
      type: "ideal",
      pointId: point.id,
      score: 10 * point.priority,
    });

    // Create good zone
    zones.push({
      centerLat: point.latitude,
      centerLng: point.longitude,
      radius: zoneRadii.good,
      type: "good",
      pointId: point.id,
      score: 7 * point.priority,
    });

    // Create far zone
    zones.push({
      centerLat: point.latitude,
      centerLng: point.longitude,
      radius: zoneRadii.far,
      type: "far",
      pointId: point.id,
      score: 3 * point.priority,
    });
  });

  // Find optimal areas by analyzing zone overlaps
  const optimalAreas = findOptimalAreas(zones, attractionPoints);

  return { zones, optimalAreas };
}

// Find areas where multiple zones overlap for maximum convenience
function findOptimalAreas(zones: CalculatedZone[], attractionPoints: AttractionPoint[]) {
  const optimalAreas: Array<{
    lat: number;
    lng: number;
    score: number;
    reasons: string[];
  }> = [];

  // Grid-based analysis around Moscow
  const moscowBounds = {
    north: 55.9,
    south: 55.6,
    east: 37.8,
    west: 37.4,
  };

  const gridSize = 0.01; // Approximately 1km
  
  for (let lat = moscowBounds.south; lat <= moscowBounds.north; lat += gridSize) {
    for (let lng = moscowBounds.west; lng <= moscowBounds.east; lng += gridSize) {
      const point = { lat, lng };
      let totalScore = 0;
      const reasons: string[] = [];
      const affectingPoints = new Set<number>();

      // Check which zones this point falls into
      zones.forEach(zone => {
        const distance = calculateDistance(
          point,
          { lat: zone.centerLat, lng: zone.centerLng }
        );

        if (distance <= zone.radius) {
          totalScore += zone.score;
          affectingPoints.add(zone.pointId);
          
          if (zone.type === "ideal") {
            reasons.push(`Идеально для точки ${zone.pointId}`);
          }
        }
      });

      // Only consider areas that are good for multiple points
      if (affectingPoints.size >= 2 && totalScore > 20) {
        optimalAreas.push({
          lat,
          lng,
          score: totalScore,
          reasons,
        });
      }
    }
  }

  // Sort by score and return top areas
  return optimalAreas
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
}

// Analyze commute efficiency for a given location
export function analyzeCommute(
  homeLat: number,
  homeLng: number,
  attractionPoints: AttractionPoint[]
): {
  averageCommute: number;
  maxCommute: number;
  score: number;
  pointAnalysis: Array<{
    pointId: number;
    distance: number;
    estimatedTime: number;
    withinLimit: boolean;
  }>;
} {
  const homePoint = { lat: homeLat, lng: homeLng };
  const pointAnalysis = attractionPoints.map(point => {
    const distance = calculateDistance(homePoint, {
      lat: point.latitude,
      lng: point.longitude,
    });
    
    // Rough time estimation: walking speed ~5km/h, public transport ~20km/h average
    const estimatedTime = Math.min(distance / 83.33, distance / 333.33); // Choose faster option
    const withinLimit = estimatedTime <= point.travelTimeMinutes;

    return {
      pointId: point.id,
      distance,
      estimatedTime,
      withinLimit,
    };
  });

  const validCommutes = pointAnalysis.filter(p => p.withinLimit);
  const averageCommute = validCommutes.length > 0 
    ? validCommutes.reduce((sum, p) => sum + p.estimatedTime, 0) / validCommutes.length
    : 0;
  
  const maxCommute = Math.max(...pointAnalysis.map(p => p.estimatedTime));
  
  // Score based on how many points are within limits and average commute time
  const score = (validCommutes.length / attractionPoints.length) * 100 - averageCommute;

  return {
    averageCommute,
    maxCommute,
    score,
    pointAnalysis,
  };
}
