// Utility functions for map-related calculations

export interface Coordinates {
  lat: number;
  lng: number;
}

// Calculate distance between two points in meters using Haversine formula
export function calculateDistance(point1: Coordinates, point2: Coordinates): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = (point1.lat * Math.PI) / 180;
  const φ2 = (point2.lat * Math.PI) / 180;
  const Δφ = ((point2.lat - point1.lat) * Math.PI) / 180;
  const Δλ = ((point2.lng - point1.lng) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

// Convert address to coordinates (mock implementation)
export async function geocodeAddress(address: string): Promise<Coordinates | null> {
  // This is a mock implementation. In a real app, you would use a geocoding service
  // like Google Maps Geocoding API, Nominatim, or similar
  
  // For demo purposes, return Moscow center with small random offset
  const moscowCenter = { lat: 55.7558, lng: 37.6176 };
  
  if (address.includes(',') && address.split(',').length === 2) {
    // Assume it's already coordinates
    const [latStr, lngStr] = address.split(',');
    const lat = parseFloat(latStr.trim());
    const lng = parseFloat(lngStr.trim());
    
    if (!isNaN(lat) && !isNaN(lng)) {
      return { lat, lng };
    }
  }
  
  // Return mock coordinates around Moscow
  return {
    lat: moscowCenter.lat + (Math.random() - 0.5) * 0.2,
    lng: moscowCenter.lng + (Math.random() - 0.5) * 0.2,
  };
}

// Convert coordinates to address (mock implementation)
export async function reverseGeocode(coordinates: Coordinates): Promise<string> {
  // This is a mock implementation. In a real app, you would use a reverse geocoding service
  return `${coordinates.lat.toFixed(4)}, ${coordinates.lng.toFixed(4)}`;
}

// Calculate optimal zone radius based on travel time and priority
export function calculateZoneRadius(travelTimeMinutes: number, priority: number): {
  ideal: number;
  good: number;
  far: number;
} {
  const baseRadius = travelTimeMinutes * 300; // More realistic: 300m per minute (public transport)
  const priorityMultiplier = Math.max(0.5, priority / 5); // Minimum 0.5 to avoid tiny zones

  return {
    ideal: baseRadius * 0.7 * priorityMultiplier,
    good: baseRadius * priorityMultiplier,
    far: baseRadius * 1.3 * priorityMultiplier,
  };
}
